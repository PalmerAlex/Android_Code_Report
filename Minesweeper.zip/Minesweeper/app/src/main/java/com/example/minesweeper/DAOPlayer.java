package com.example.minesweeper;

/**   This Class is responsible for adding a new score to the database
 *  * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * constructor of DAOPlayer gets the reference to the database and takes in the parameter difficulty at which it then knows which part of the database to write to
 * task add takes in a player object and pushes to the database, creating a unique id.
 */
public class DAOPlayer {
    private DatabaseReference databaseReference;
    public DAOPlayer(String difficulty){
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        databaseReference = db.getReference().child(difficulty);
    }

    public Task<Void> add(com.example.minesweeper.Player player){

        return databaseReference.push().setValue(player);
    }
}
