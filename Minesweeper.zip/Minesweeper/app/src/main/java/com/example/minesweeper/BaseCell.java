package com.example.minesweeper;
/**  Abstract class that includes all the base values and attributes for each cell within minesweeper
 * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */


import android.content.Context;
import android.util.Log;
import android.view.View;

import java.net.ContentHandler;
public abstract class BaseCell extends View { //cannot be instanced

    private int value; // 0s 1s and -1s for bomb
    private  boolean isBomb;
    private boolean isRevealed;

    private boolean isClicked;
    private  boolean isFlagged;

    private int x,y;
    private int position;

    /**
     * @param context
     * This is the constructor of basecell, takes the current context as a parameter and calls view's constructor with the same context
     */
    public BaseCell(Context context){
        super(context);
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        isBomb = false;
        isRevealed = false;
        isClicked = false;
        isFlagged = false;

        if( value == -1){
            isBomb = true;
        }

        this.value = value;
    }

    public boolean isBomb() {
        return isBomb;
    }
    public void setBomb(boolean bomb) {
        isBomb = bomb;
    }

    public boolean isRevealed() {
        return isRevealed;
    }

    public void setRevealed() {
        isRevealed = true;
        invalidate();
    }

    public boolean isClicked() {
        return isClicked;
    }

    public void setClicked() {
        this.isClicked = true;
        this.isRevealed = true;

        invalidate();
    }

    public boolean isFlagged() {
        return isFlagged;
    }

    public void setFlagged(boolean flagged) {
        isFlagged = flagged;
    }

    public int getXPos() {
        return x;
    }

    public int getYPos() {
        return y;
    }


    public int getPosition() {
        return position;
    }

    public void setPosition(int x, int y){
        this.x = x;
        this.y = y;
        this.position = y * Game.theWidth + x;
        invalidate();
    }



}
