package com.example.minesweeper;

/**  This class is responsible for the drawing and manipulation of a cell that will be used to represent the whole minesweeper grid
 *  * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

/**
 * extends abstract class basecell and implements onclick.
 */
public class Cell extends BaseCell implements View.OnClickListener, View.OnLongClickListener{ //inherits BaseCell

    /**
     * sets the position of the cell and sets up the listeners
     * @param context current context within the program
     * @param x to set its position within the grid, x is given
     * @param y to set its position within the grid, y is given
     */
//constructor
    public Cell(Context context, int x, int y){
        super(context);
    //every button is going to be a square
        setPosition(x, y);


        setOnClickListener(this);
        setOnLongClickListener(this);
    }

    /**
     * measures the cell so it can be scaled appropriately
     * @param widthMeasureSpec width of the cell
     * @param heightMeasureSpec height of the cell
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec){
        super.onMeasure(widthMeasureSpec,widthMeasureSpec);
    }

    /**
     * checks if the cell is flagged or not, then calls the click method in GameEngine respectively.
     * @param v  takes the current view at which the user has just clicked on
     */
    @Override
    public void onClick(View v) {
        if(!(this.isFlagged())){
            GameEngine.getInstance().click( getXPos(), getYPos() );
        }


    }

    /**
     * handles if the user long presses a cell, setting the cell to flagged if its not revealed.
     * @param view takes the current view at which the user has just long clicked on
     * @return
     */
    @Override
    public boolean onLongClick(View view) {
        if(!(this.isRevealed())){
            GameEngine.getInstance().flag(getXPos(),getYPos());
            return true;
        }

        return false;


    }

    /**
     * calls the separate draw methods depending on the different current state of the cell, when Invalidate() gets called elsewhere in the program, this procedure gets called
     * @param canvas current canvas of the cell
     */
    @Override
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        drawButton(canvas);

        if(isFlagged()){ //checks if a cell is flagged and if so draw a flag
            drawFlag(canvas);

        }
        else if (isRevealed() && isBomb() && !isClicked()){
            drawNormalBomb(canvas);
        }
        else{ //if not flagged
            if(isClicked() ){
                if (getValue() == -1){
                    drawBombExploded(canvas);

                }
                else{ //if not clicked
                    drawNumber((canvas));
                }

            }
            else{
                drawButton((canvas));
            }
        }
    }

    /**
     * depending on the value of the cell, which was generated using generator, it will set the drawable of the cell to its corresponding number
     * @param canvas current canvas of the cell
     */
    private void drawNumber (Canvas canvas){
        Drawable drawable = null;

        switch (getValue()){
            case 0:
                drawable = ContextCompat.getDrawable(getContext(), R.drawable.number_0);
                break;
            case 1:
                drawable = ContextCompat.getDrawable(getContext(), R.drawable.number_1);
                break;
            case 2:
                drawable = ContextCompat.getDrawable(getContext(), R.drawable.number_2);
                break;
            case 3:
                drawable = ContextCompat.getDrawable(getContext(), R.drawable.number_3);
                break;
            case 4:
                drawable = ContextCompat.getDrawable(getContext(), R.drawable.number_4);
                break;
            case 5:
                drawable = ContextCompat.getDrawable(getContext(), R.drawable.number_5);
                break;
            case 6:
                drawable = ContextCompat.getDrawable(getContext(), R.drawable.number_6);
                break;
            case 7:
                drawable = ContextCompat.getDrawable(getContext(), R.drawable.number_7);
                break;
            case 8:
                drawable = ContextCompat.getDrawable(getContext(), R.drawable.number_8);
                break;
        }

        drawable.setBounds(0,0,getWidth(), getHeight());
        drawable.draw((canvas));

    }


    /**
     * draws a normal bomb
     * @param canvas
     */
    private  void drawNormalBomb(Canvas canvas){
        Drawable drawable = ContextCompat.getDrawable(getContext(), R.drawable.bomb_normal);
        drawable.setBounds(0,0,getWidth(),getHeight()); //scale to size of cell
        drawable.draw(canvas);
    }

    /**
     * draws a exploded bomb to canvas
     * @param canvas
     */
    private  void drawBombExploded(Canvas canvas){
        Drawable drawable = ContextCompat.getDrawable(getContext(), R.drawable.bomb_exploaded);
        drawable.setBounds(0,0,getWidth(),getHeight()); //scale to size of cell
        drawable.draw(canvas);
    }

    /**
     * draws a flag to the canvas
     * @param canvas
     */
    private  void drawFlag(Canvas canvas){
        Log.d("CELL", "drawFlag: ");
        Drawable drawable = ContextCompat.getDrawable(getContext(), R.drawable.flag);
        drawable.setBounds(0,0,getWidth(),getHeight()); //scale to size of cell
        drawable.draw(canvas);
    }

    /**
     * draws a button to the canvas
     * @param canvas
     */
    private void drawButton(Canvas canvas){
        Drawable drawable = ContextCompat.getDrawable(getContext(), R.drawable.button);
        drawable.setBounds(0,0,getWidth(),getHeight()); //scale to size of cell
        drawable.draw(canvas);
    }

}
