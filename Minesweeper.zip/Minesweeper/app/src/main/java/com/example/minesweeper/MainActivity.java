package com.example.minesweeper;
/**  This is the main activity, where startup of the program occurs. This acts as thr main menu for the game
 *  * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button test;
    public AlertDialog.Builder dialogBuilder;
    public  AlertDialog dialog;

    /**
     * When mainacticty is made, this is called.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindow();
    }

    /**
     * this code is executed if the start button is clicked
     * @param v
     */
    public void onStartClick(View v){
        Intent i = new Intent(MainActivity.this, Menu.class);
        startActivity(i);
    }
    /**
     * this code is executed if the leaderboard button is clicked
     * @param v
     */
    public void onLeaderboardClick(View v){
        Intent i = new Intent(MainActivity.this, Leaderboards.class);
        startActivity(i);
    }
    /**
     * this code is executed if the exit button is clicked
     * @param v
     */
    public void onExitClick(View v){
        System.exit(0);
    }
    private void setupWindow(){
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View decorView = getWindow().getDecorView();

        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
    }

    /**
     * this handles the creation of the help dialog, when clicked the help dialog is created
     * @param v
     */
    public void createNewCustomDialog(View v){
        dialogBuilder = new AlertDialog.Builder(this);
        final View customPopupView  = getLayoutInflater().inflate(R.layout.activity_help, null);
        dialogBuilder.setView(customPopupView);
        dialog = dialogBuilder.create();
        dialog.show();
    }

    /**
     * handles the exit button withint the help dialog
     * @param v
     */
    public void onCloseCLick(View v){
        dialog.cancel();
    }
}