package com.example.minesweeper;
/**   This class handles the grid view for the minesweeper game, containing all the cells in one grid
 *  * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */
import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;

import java.util.jar.Attributes;

public class Grid extends GridView {

    /**
     * Constructor for Grid, setting up the GridAdapters and columns
     * @param context
     * @param attributes
     */
    public Grid(Context context, AttributeSet attributes){
        super(context,attributes);

        //GameEngine.getInstance().createGrid((context));

        setNumColumns(Game.theWidth);
        setAdapter(new GridAdapter());
    }

    /**
     * Measures the width and height of the grid
     * @param widthMeasureSpec
     * @param heightMeasureSpec
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec){
        super.onMeasure(widthMeasureSpec,heightMeasureSpec);
    }


    /**
     * Exending the base Adapter class so that i can manipulate some functions within BaseAdapter
     */
    private class GridAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return GameEngine.getInstance().getWIDTH() * GameEngine.getInstance().getHEIGHT();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {
            return GameEngine.getInstance().getCellAt(position);
        }
    }
}
