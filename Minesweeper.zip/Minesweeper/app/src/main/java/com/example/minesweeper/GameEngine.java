package com.example.minesweeper;
/**   This class creates an instance of itself which is the game. It creates the minesweeper grid depending on the Game width height and bomb values. sets up all the views and generates the game itself
 *  * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */
import android.content.Context;
import android.media.MediaPlayer;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.util.concurrent.BlockingDeque;

public class GameEngine {
    private static GameEngine instance; //creates instance of itself within itself

    private static int flag_number;

    public static  int BOMB_NUMBER;
    public static  int WIDTH;
    public static  int HEIGHT;
    public static int faceInstance;

    private  boolean gameWon = false;

    public int score;

    public Cell[][] MinesweeperGrid = new Cell[WIDTH][HEIGHT];

    private Context context; //to connect to text views

    public static GameEngine getInstance() {
        //gets the current instance
        if (instance == null) { //if there is no instance create a new one

            instance = new GameEngine();

        }
        return instance; //return statement
    }

    /**
     * sets the GameEngine's width height and bombs accordingly
     * @param w  width
     * @param h height
     * @param b bombs
     */
    public static void setSizes(int w, int h, int b){
        WIDTH = w;
        HEIGHT = h;
        BOMB_NUMBER = b;
    }
    public static GameEngine makeNewInstance(){
        instance = null;
        faceInstance = 2;
        //instance = new GameEngine();

        return new GameEngine();
    }

    /**
     * constructor for GameEngine, sets the width and height by default from Game. using static references
     */
    private GameEngine() {


        WIDTH = Game.theWidth;
        HEIGHT = Game.theHeight;
        BOMB_NUMBER = Game.theBombNumber;
        flag_number = 0;
    }

    /**
     * Created the grid by creating a 2D array with the values bombs, width and height
     * @param context
     */
    public void createGrid(Context context) {

        this.context = context;
        //create and store the grid.
        int[][] GeneratedGrid = Generator.generate(BOMB_NUMBER, WIDTH, HEIGHT);
        PrintGrid.print(GeneratedGrid,WIDTH,HEIGHT);
        setGrid(context,GeneratedGrid);
    }

    public  int getFaceInstance(){
        return  faceInstance;
    }

    /**
     * Sets up  the grid by creating new cells and storing them in MinesweeperGrid
     * @param context
     * @param grid
     */
    private void setGrid(final Context context, final int[][] grid){
        for(int i =0; i<WIDTH; i++){
            for(int u =0; u<HEIGHT;u++){
                if(MinesweeperGrid[i][u] == null){ //if the cell is null or not, as we are creating a new button for the grid
                    MinesweeperGrid[i][u] = new Cell(context, i,u);


                }
                MinesweeperGrid[i][u].setValue(grid[i][u]);
                MinesweeperGrid[i][u].invalidate();
            }
        }
    }

    public Cell getCellAt(int position){
        int x = position % WIDTH;
        int y = position / WIDTH;

        return MinesweeperGrid[x][y];
    }


    public Cell getCellAt(int x, int y){
        return MinesweeperGrid[x][y];
    }

    /**
     * Handles if a player clicks on a cell, from the cell itself.
     * Checks if the cell is a bomb if it is then game over, else sets the cell to clicked and then unreveals it.
     * @param x
     * @param y
     */
    public void click( int x , int y ){
        if( x >= 0 && y >= 0 && x < WIDTH && y < HEIGHT && !getCellAt(x,y).isClicked() ) {
            getCellAt(x, y).setClicked();
            Game.theScore++;
            faceInstance = 2;
            if (getCellAt(x, y).getValue() == 0) {
                for (int xt = -1; xt <= 1; xt++) {
                    for (int yt = -1; yt <= 1; yt++) {
                        if (xt != yt) {

                            click(x + xt, y + yt);

                        }
                    }
                }
            }

            if (getCellAt(x, y).isBomb()) {
                faceInstance = 3;
                onGameLost();
            }


        }

        checkEnd();


    }

    /**
     * checks if the end has happened
     * Scans through every cell to see if it has been revealed.
     * If all bombs are flagged and every other cell is clicked then game has been won and then endGame gets called
     * @return
     */
    private  boolean checkEnd(){
        int bombNotFound = BOMB_NUMBER;
        int notRevealed = WIDTH * HEIGHT;

        for ( int x = 0 ; x < WIDTH ; x++ ){
            for( int y = 0 ; y < HEIGHT ; y++ ){

                if( getCellAt(x,y).isRevealed() || getCellAt(x,y).isFlagged() ){
                    notRevealed--;

                }

                if( getCellAt(x,y).isFlagged() && getCellAt(x,y).isBomb() ){
                    bombNotFound--;
                }
            }
        }
        if( bombNotFound == 0 && notRevealed == 0 ){
            faceInstance = 0;
            onGameWon();
        }
        return false;
    }

    /**
     * handles the flagging of a cell.
     * if the cell is flagged then unflag it and vice versa
     * @param x
     * @param y
     */
    //if flagged, we are deflagging and vice versa
    public void flag(int x, int y){
        faceInstance = 1;
        boolean isFlagged = getCellAt(x,y).isFlagged();
        if(flag_number >= BOMB_NUMBER && isFlagged) {
            getCellAt(x,y).setFlagged(false);

            flag_number--;
        }
        else{
            if(getCellAt(x,y).isFlagged()){
                flag_number--;
                getCellAt(x,y).setFlagged(!isFlagged);
            }
        }


        if (!isFlagged && !(flag_number >= BOMB_NUMBER)){

            Log.d("GameEngine", "flag: flag number increased");
            flag_number++;
            getCellAt(x,y).setFlagged(true);
            checkEnd();


        }
        else if (flag_number == BOMB_NUMBER){
            Toast.makeText(context, "Out of usable flags", Toast.LENGTH_SHORT).show();
        }
        getCellAt(x,y).invalidate();

    }


    /**
     * handles if the game has been won.
     * setting faceinstance to 0 which is cool face
     * sets gameWOn to true
     */
private void onGameWon(){
    Toast.makeText(context,"Game won", Toast.LENGTH_SHORT).show();
    faceInstance = 0;
    gameWon = true;
    end();
}

    /**
     * calls end without chaning any other values
     */
    private void onGameLost(){
        Toast.makeText(context, "Game lost", Toast.LENGTH_LONG).show();
        end();
    }

    /**
     * ends the game by looping through all the cells and unrevealing them all so that the user can see where the bombs were
     */
    public void end(){
        for (int x = 0; x < WIDTH; x++){
            for (int y =0; y< HEIGHT; y++) {
                getCellAt(x,y).setRevealed();
                getCellAt(x,y).setEnabled(false);

            }}
        Game.end(faceInstance);
    }
    public boolean getGameWon(){
        return gameWon;
    }
public  int getHEIGHT(){
        return HEIGHT;
}
public  int getWIDTH(){
        return WIDTH;
}
    public int getFlag_number(){
        return flag_number;
    }
}


