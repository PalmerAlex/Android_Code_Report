package com.example.minesweeper;
/**   This class handles the leaderboards for the project, displaying them in a logical order
 *  * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;

public class Leaderboards extends AppCompatActivity {
private ListView leaderboardListView;
public ArrayAdapter arrayAdapter;
private  ArrayList<String> names = new ArrayList<String>();
    private  ArrayList<String> scores = new ArrayList<String>();
    private  ArrayList<String> leaderboardArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindow();
        setContentView(R.layout.activity_leaderboards);
        leaderboardListView = findViewById(R.id.leaderboardsListView);
    }

    /**
     * clears the conetents of the arrayAdapter so that when a new query is requested there is no overlapping
     */
    private void clearList(){
        leaderboardArrayList = new ArrayList<String>();
            arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,leaderboardArrayList);


    }

    /**
     * handles easy click
     * @param v
     */
    public void onEasyLeaderboardClick(View v){

        loadDatabase("Easy");
        clearList();

    }
    /**
     * handles Intermediate click
     * @param v
     */
    public void onIntermediateLeaderboardClick(View v){
        clearList();
        loadDatabase("Intermediate");

    }
    /**
     * handles hard click
     * @param v
     */
    public void onHardLeaderboardClick(View v){
        loadDatabase("Hard");
        clearList();

    }
    /**
     * handles Expert click
     * @param v
     */
    public void onExpertLeaderboardClick(View v){
        loadDatabase("Expert");
        clearList();
    }

    /**
     * loads the current database then displays it after it has been loaded
     * @param type this is the type of difficulty eg easy or hard
     */
private void loadDatabase(String type){
    DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child(type);
    reference.orderByChild("score").addValueEventListener(new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot datasnapshot) {
            int position = (int) datasnapshot.getChildrenCount();
            for(DataSnapshot snapshot : datasnapshot.getChildren()){
                String name = snapshot.child("name").getValue().toString();
                String score = snapshot.child("score").getValue().toString();
            leaderboardArrayList.add("       "+position + "                      "+name+ "                "+score);
            position--;
            }
            leaderboardArrayList.add("Position                Name                Score");
            Log.d("TAG", "" +leaderboardArrayList);
            Collections.reverse(leaderboardArrayList);
            Log.d("TAG", "" +leaderboardArrayList);
            //arrayAdapter.add(leaderboardArrayList);
            leaderboardListView.setAdapter(arrayAdapter);

        }

        @Override
        public void onCancelled(@NonNull DatabaseError error) {

        }
    });
}


    /**
     * takes the user to the home page
     * @param v
     */
public void leaderboardsHomeButtonClicked(View v){
    Intent i = new Intent(Leaderboards.this, MainActivity.class);
    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
    startActivity(i);
}

    /**
     * sets up the window so that the activity is full screen
     */
    private  void setupWindow(){
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        View decorView = getWindow().getDecorView();

        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);


    }

}