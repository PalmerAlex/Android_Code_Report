package com.example.minesweeper;
/**   This class is used to print the grid of minesweeper to the logcat so that testing of minesweeper can be visualised. This was mainly useful for before i graphically created minesweeper
 *  * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */
import android.util.Log;

public class PrintGrid {

    /**
     * Prints aa given grid to logcat
     * @param grid
     * @param width
     * @param height
     */
    public static void print( final int[][] grid , final int width , final int height ){
        Log.e("printer", "printed");
        for( int x = 0 ; x < width ; x++ ){
            String printedText = "| ";
            for( int y = 0 ; y < height ; y++ ){
                printedText += String.valueOf(grid[x][y]).replace("-1", "B") + " | ";
            }
            Log.e("GameEngine",printedText);
        }
    }

    }

