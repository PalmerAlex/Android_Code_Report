package com.example.minesweeper;
/**   This activity is to handle the GameEngine, manipulate values, thread a timer and ui as well as update to databases the values of scores
 *  * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.GridView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class Game extends AppCompatActivity {

public static int theWidth;
public static int theHeight;
public static int theBombNumber;
public static int theScore;
private static int timeRemaining = 0;

private int test;

private static String theDifficulty, theName;

private static MediaPlayer bombSound,winSounds,expertSounds,newHighScoreSounds;
private static MediaPlayer backgroundSong;



private final int MAXTIME = 999999; //max time for a single game is 999 seconds.

public static TextView flagTxtView, timeTextView;

public GridView minesweeper;

public static boolean gameStarted;

private boolean isRestarted;

private static Button endGameButton;

public static ImageView face;

private Handler handler;
private Handler utilHandler;

private ArrayList<String> names = new ArrayList<String>();
private ArrayList<String> scores = new ArrayList<String>();


    /**
     * This procedure is called when Game is first created.
     * All views are instanced here as well as sharedpreferneces and other attributes.
     * The method also creates two threads, one for the timer, and one for the UI display updates.
     * the timer thread allows the program to track the time taken for the player to complete the game
     * the UI thread handles the flag counter as well as the dynamic face image.
     * @param savedInstanceState gets the current bundle
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindow();
        backgroundSong = MediaPlayer.create(Game.this,R.raw.background_music);
        bombSound =MediaPlayer.create(Game.this, R.raw.bomb_blowup);
        winSounds = MediaPlayer.create(Game.this, R.raw.game_win);
        expertSounds = MediaPlayer.create(Game.this, R.raw.expert);
        newHighScoreSounds = MediaPlayer.create(Game.this,R.raw.highscore);
        backgroundSong.start();
        SharedPreferences sp = getSharedPreferences("GridInfo", Context.MODE_PRIVATE);
        theWidth = sp.getInt("WIDTH", 0);
        theHeight = sp.getInt("HEIGHT", 0);
        theBombNumber = sp.getInt("BOMB", 0);
        theDifficulty = sp.getString("DIFFICULTY", "");
        theName = sp.getString("NAME", "");
        flagTxtView = (TextView) findViewById(R.id.flagTextView);
        minesweeper = (GridView) findViewById(R.id.minesweeperGridView);
        handler = new Handler();
        utilHandler = new Handler();
        gameStarted = true;
        final Runnable timer = new Runnable() {
            @Override
            public void run() {

                timeRemaining = timeRemaining + 1000;
                if (timeRemaining <= MAXTIME && gameStarted == true){
                    updateTimer();
                    handler.postDelayed(this,1000);
                }
                if (timeRemaining == MAXTIME){
                    GameEngine.getInstance().end();
                }

            }
        };
        handler.postDelayed(timer,1000);

        final Runnable background = new Runnable() {
            @Override
            public void run() {
                if(backgroundSong.isPlaying() == false && gameStarted == true){
                    backgroundSong.start();
                }
                if (GameEngine.getInstance().faceInstance == 3){
                    Drawable drawable = ContextCompat.getDrawable(Game.this, R.drawable.destroyed_face);
                    face.setImageDrawable(drawable);
                }
                if (GameEngine.getInstance().faceInstance == 0){
                    Drawable drawable = ContextCompat.getDrawable(Game.this, R.drawable.cool_face);
                    face.setImageDrawable(drawable);
                }
                if (gameStarted == true){

                    updateFlags();
                    updateFace();

                    utilHandler.postDelayed(this,1);
                    //timeTextView.setText("timeRemaining");
                }
                else{
                    showEndGameDialog();
                }

            }
        };
        utilHandler.postDelayed(background,1);
        start();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child(theDifficulty);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot datasnapshot) {
                for(DataSnapshot snapshot : datasnapshot.getChildren()){
                    String name = snapshot.child("name").getValue().toString();
                    String score = snapshot.child("score").getValue().toString();
                    names.add(name);
                    scores.add(score);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    /**
     * updates the faces of the face view depending on the current instance of GameEngine, if lost then put sad face, etc..
     */
    public void updateFace(){
        Drawable drawable = null;

        face = (ImageView) findViewById(R.id.FaceImageView);
        int faceType = GameEngine.getInstance().getFaceInstance();
        switch (faceType) {
            case 0:
                drawable = ContextCompat.getDrawable(Game.this, R.drawable.cool_face);
                break;
            case 1:
                drawable = ContextCompat.getDrawable(Game.this, R.drawable.shocked_face);
                break;
            case 2:
                drawable = ContextCompat.getDrawable(Game.this, R.drawable.smile_face);
                break;
            case 3:
                drawable = ContextCompat.getDrawable(Game.this, R.drawable.destroyed_face);
                break;
            case 5:
                break;
               
        }
        face.setImageDrawable(drawable);
    }

    /**
     * Updates the timer by setting the value of the TextView to the time remaining
     */
public  void updateTimer(){
    timeTextView = (TextView) findViewById(R.id.TimerTextBox);
    timeTextView.setText(String.valueOf(timeRemaining /1000));
}

    /**
     * Updates the flag count by setting the value of TextView to the a calculated number of flags remaining
     */
public void updateFlags(){
    flagTxtView = (TextView) findViewById(R.id.flagTextView);
    flagTxtView.setText(String.valueOf(theBombNumber - GameEngine.getInstance().getFlag_number()));
}

    /**
     * called from onCreate
     * Sets up the game, creating an new instance of GameEngine, setting the layouts and parsing in the values of width height and bombs
     */
private  void start(){
    setContentView(R.layout.activity_game);

    GameEngine.getInstance();
    GameEngine.makeNewInstance();
    GameEngine.setSizes(theWidth,theHeight,theBombNumber);
    GameEngine.getInstance().createGrid(this);
}

    /**
     * Restarts the game by resetting all static values to their default values
     * creates a new intent of the menu activity so that the user can select a different difficulty or play again
     * @param v from the button clicked
     */
    public void restart(View v){
        test = 1;
        gameStarted = false;
        isRestarted = true;
        backgroundSong.stop();
        winSounds.stop();
        theScore = 0;
        SharedPreferences sp = getSharedPreferences("GridInfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        Log.d("TAG", "restart: "+theName);
        editor.putString("NAME",theName);
        editor.commit();
        Intent i = new Intent(Game.this, Menu.class);
             // Specify any activity here e.g. home or splash or login etc
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra("EXIT", true);
        startActivity(i);
        finish();

    }

    /**
     * sets up the android screen so that the activity is full screen to improve UI
     */
    private  void setupWindow(){
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        View decorView = getWindow().getDecorView();

        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);


    }

    /**
     * plays sounds from MediaPlayer according to end game type
     * @param type end type from GameEngine, if 3 then lost, if 0 then won
     */
    public static void end(int type){
        backgroundSong.stop();
        gameStarted = false;
        if(type == 3){
            bombSound.start();
        }
        if(type == 0){
            if(theDifficulty.equals("Expert")){
                expertSounds.start();
            }
            winSounds.start();
        }


        gameStarted = false;
    }

    /**
     * handles the end game leaderboards, firstly by checking if the game was restarted or not, then parsing the values into a custom class that uploads the data into the database
     */
    public void handleEndGameLeaderboards(){
        if (isRestarted == false){
            DAOPlayer dao = new DAOPlayer(theDifficulty);
            Player player = new Player(theName,theScore);
            dao.add(player);
        }

        if(newHighScore() && GameEngine.getInstance().getGameWon() && theDifficulty != "Custom"){
            newHighScoreSounds.start();
        }
    }

    /**
     * checks if the end value calculated is greater than the online scores
     * @return boolean
     */
    private boolean newHighScore(){

        for(String score : scores){
            if(theScore <= Integer.parseInt(score)){
                return false;
            }

        }
        return true;
    }

    /**
     * shows the end game dialog, by calculating final score and giving separate messages depending if won or lost
     */
    private void showEndGameDialog(){
        if (GameEngine.getInstance().getGameWon()){
            endGameButton = (Button) findViewById(R.id.endGamePopUpButton);
            theScore = (((theHeight * theWidth) - theBombNumber )*99999/ timeRemaining );
            timeRemaining = 0;
            endGameButton.setVisibility(View.VISIBLE);
            endGameButton.setText("GAME WON, SCORE: "+ theScore);
            handleEndGameLeaderboards();
        }
        else {
            endGameButton = (Button) findViewById(R.id.endGamePopUpButton);
            theScore = 0;
            timeRemaining = 0;
            endGameButton.setVisibility(View.VISIBLE);
            endGameButton.setText("GAME OVER, SCORE: " + theScore);
        }
    }

    /**
     * android method called when Game is started
     */
    protected void onStart(){
        super.onStart();
        Log.d("TAG", "started");
    }

    /**
     * when game is paused, pause the background song
     */
    protected void onPause(){
        super.onPause();
        backgroundSong.pause();
    }

    /**
     * when the activity id resumed, the background song starts again
     */
    protected void onResume(){
        super.onResume();
        backgroundSong.start();
        Log.d("TAG", "onResume: ");
    }

    /**
     * When the program is stopped (by pressing the back button) then the game will restart itself and clear all other activities
     */
    protected  void onStop(){
        super.onStop();
        if(!(test == 1)){
            gameStarted = false;
            isRestarted = true;
            backgroundSong.stop();
            winSounds.stop();
            theScore = 0;
            SharedPreferences sp = getSharedPreferences("GridInfo", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("NAME",theName);
            editor.commit();
            Intent i = new Intent(Game.this, Menu.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.putExtra("EXIT", true);
            startActivity(i);
            finish();
        }

    }
}