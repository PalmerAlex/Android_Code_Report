package com.example.minesweeper;
/**   This activity is responsible for the selection of the type of game at which the player will play
 *
 *  * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;


public class Menu extends AppCompatActivity {
    private int width,height,bomb;
    private String difficulty, name;
    private int customWidth,customHeight,customBomb;
    private boolean isChecked = false;
    private ImageButton easyBtn, intermediateBtn, hardBtn, expertBtn, customBtn;
    private EditText nameEditText;
    private  ImageView nameTextView;
    private TextView  customBombTextView, customWidthTextView, customHeightTextView;
    private SharedPreferences sp;
    private SeekBar bombBar, widthBar, heightBar;

    /**
     * called when the intent is created
     * sets up default values and gets the views into variables
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindow();
        setContentView(R.layout.activity_menu);
        sp = getSharedPreferences("GridInfo",Context.MODE_PRIVATE);
        name = sp.getString("NAME", "");
        Log.d("TAG", "onCreate: name: "+name);
        easyBtn = (ImageButton) findViewById(R.id.easyButton);
        intermediateBtn = (ImageButton) findViewById(R.id.intermediateButton);
        hardBtn = (ImageButton) findViewById(R.id.hardButton);
        expertBtn = (ImageButton) findViewById(R.id.expertButton);
        customBtn = (ImageButton) findViewById(R.id.customButton);
        nameEditText = (EditText) findViewById(R.id.editTextTextPersonName);
        nameEditText.setText(name);
        customBombTextView  =(TextView) findViewById(R.id.bombCustomTextView);
        customHeightTextView = (TextView) findViewById(R.id.heightCustomTextView);
        customWidthTextView = (TextView) findViewById(R.id.widthCustomTextView);
        customBtn.setEnabled(false);
        bombBar = (SeekBar) findViewById(R.id.bombSeekBar);
        heightBar = (SeekBar) findViewById(R.id.heightSeekBar);
        widthBar = (SeekBar) findViewById(R.id.widthSeekBar);



        nameTextView = (ImageView) findViewById(R.id.nameInputTextBox);
        handleSeekBars();


    }

    /**
     * This method's purpose is to validate the seek bars so that illegal sizes do not get entered
     * hence preventing the game from crashing and or having logic errors
     */
public void validateSeekBars(){
        if(bombBar.getProgress() > heightBar.getProgress() * widthBar.getProgress()){
            // to stop program from crashing
            customBombTextView.setText("Bombs: "+ (heightBar.getProgress() * widthBar.getProgress()));
            customBomb = heightBar.getProgress() * widthBar.getProgress();
            bombBar.setMax(heightBar.getProgress() * widthBar.getProgress());
        }
        else{
            bombBar.setMax(20);
        }
        if(heightBar.getProgress() > widthBar.getProgress() *1.3){
            //Toast.makeText(this, "Error, Height must not exceed much greater than width.",Toast.LENGTH_SHORT).show();
            customHeightTextView.setText("Height: "+ widthBar.getProgress());
            customHeight = (int) (widthBar.getProgress() *1.3);
            heightBar.setMax((int) (widthBar.getProgress() * 1.3));
        }
        else{
            heightBar.setMax(20);
        }
}

    /**
     * This method's purpose is to setup the seekbars and their listeners
     * When a player changes the slider, the onProgressChanged method will be called that updates the seek bars values.
     */
public void handleSeekBars(){
    heightBar.setMax(20);
    widthBar.setMax(20);
    bombBar.setMax(20);
    customWidth = 7;
    customHeight = 10;
    customBomb = 5;
    heightBar.setProgress(10);
    widthBar.setProgress(7);
    bombBar.setProgress(5);
    customBombTextView.setText(""+bombBar.getProgress());
    customHeightTextView.setText(""+heightBar.getProgress());
    customWidthTextView.setText(""+widthBar.getProgress());
    customBombTextView.setText("Bombs: " +(bombBar.getProgress()   ));
    customHeightTextView.setText("Height: " +( heightBar.getProgress()  ));
    customWidthTextView.setText("Width: " +( widthBar.getProgress()  ));
    bombBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            customBombTextView.setText("Bombs: " +( progress  ));
            customBomb = progress;
            validateSeekBars();
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    });
    heightBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            customHeightTextView.setText("Height: " +( progress  ));
            customHeight = progress;
            validateSeekBars();
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    });
    widthBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            customWidthTextView.setText("Width: " +( progress  ));
            customWidth  = progress;
            validateSeekBars();
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    });
}

    /**
     * Method to handle a player clicking on the easy button
     * @param v
     */
    public void easyBtnClick(View v){
        width = 9;
        height = 9;
        bomb = 10;
        difficulty = "Easy";
        start();
    }
    /**
     * Method to handle a player clicking on the intermediate button
     * @param v
     */
    public void intermediateBtnClick(View v){
        width = 11;
        height = 13;
        difficulty = "Intermediate";
        bomb = 20;
        start();
    }
    /**
     * Method to handle a player clicking on the hard button
     * @param v
     */
    public void hardBtnClick(View v){
        width = 13;
        height = 13;
        difficulty = "Hard";
        bomb = 55;

        start();
    }
    /**
     * Method to handle a player clicking on the intermediate button
     * @param v
     */
    public void  expertBtnClick(View v){
        width = 14;
        height = 18;
        difficulty = "Expert";
        bomb = 99;

        start();
    }
    /**
     * Method to handle a player clicking on the custom button
     * @param v
     */
    public void customClicked(View v){
        difficulty ="Custom";
        if (bombBar.getProgress() == 0 || widthBar.getProgress() == 0 || widthBar.getProgress() == 0){
            Toast.makeText(this,"Width, Height or Bombs cannot have the value of 0",Toast.LENGTH_SHORT).show();
        }
        else{
            Intent i = new Intent(Menu.this, Game.class);
            SharedPreferences.Editor editor = sp.edit();

            editor.putInt("HEIGHT", customHeight);
            editor.putInt("WIDTH", customWidth);
            editor.putInt("BOMB", customBomb);
            editor.putString("DIFFICULTY", difficulty);
            editor.commit();
            startActivity(i);
        }


    }

    /**
     * Starts the game by creating a new intent with the game class. adding sharedpreferences including the size of the game and number of bombs
     */
    void start() {
        Intent i = new Intent(Menu.this, Game.class);
        SharedPreferences.Editor editor = sp.edit();
        name = nameEditText.getText().toString();
        if (name.length() < 4 || name.length() >15){
            Toast.makeText(this, "Name must not be empty, minimum 4 characters and max 15 characters",Toast.LENGTH_SHORT).show();
        }
        else{
            editor.putInt("HEIGHT", height);
            editor.putInt("WIDTH", width);
            editor.putInt("BOMB", bomb);
            editor.putString("DIFFICULTY", difficulty);
            editor.putString("NAME", name);
            editor.commit();
            startActivity(i);
        }

    }

    /**
     * This method is responsible for handling when the home button is clicked
     * @param v
     */
    public  void onHomeClick(View v){
        Intent i = new Intent(Menu.this, MainActivity.class);
        SharedPreferences.Editor editor = sp.edit();
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        name = nameEditText.getText().toString();
        editor.putString("NAME", name);
        editor.commit();
        startActivity(i);
    }

    /**
     * the purpose of this method is to flip the visibilities of the buttons and seekbars
     * this is done so that the user can focus on the custom and don't accidentally press on the difficulty buttons
     * @param v
     */
    public  void handleCustom(View v){
        isChecked = !isChecked;
        if(isChecked){
            easyBtn.setVisibility(View.INVISIBLE);
            intermediateBtn.setVisibility(View.INVISIBLE);
            hardBtn.setVisibility(View.INVISIBLE);
            expertBtn.setVisibility(View.INVISIBLE);
            nameEditText.setVisibility(View.INVISIBLE);
            nameTextView.setVisibility(View.INVISIBLE);
            customBtn.setEnabled(true);

            customWidthTextView.setVisibility(View.VISIBLE);
            customHeightTextView.setVisibility(View.VISIBLE);
            customBombTextView.setVisibility(View.VISIBLE);

            bombBar.setVisibility(View.VISIBLE);
            widthBar.setVisibility(View.VISIBLE);
            heightBar.setVisibility(View.VISIBLE);
        }
        else{
            customWidthTextView.setVisibility(View.INVISIBLE);
            customHeightTextView.setVisibility(View.INVISIBLE);
            customBombTextView.setVisibility(View.INVISIBLE);

            bombBar.setVisibility(View.INVISIBLE);
            widthBar.setVisibility(View.INVISIBLE);
            heightBar.setVisibility(View.INVISIBLE);
            easyBtn.setVisibility(View.VISIBLE);
            intermediateBtn.setVisibility(View.VISIBLE);
            hardBtn.setVisibility(View.VISIBLE);
            expertBtn.setVisibility(View.VISIBLE);
            nameEditText.setVisibility(View.VISIBLE);
            nameTextView.setVisibility(View.VISIBLE);
            customBtn.setEnabled(false);


        }

    }

    /**
     * Sets up the window so that it is in full screen mode
     */
    private  void setupWindow(){
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        View decorView = getWindow().getDecorView();

//        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
//                | View.SYSTEM_UI_FLAG_FULLSCREEN;
//        decorView.setSystemUiVisibility(uiOptions);


    }
}