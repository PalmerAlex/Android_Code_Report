package com.example.minesweeper;
/**   This class generates the minesweeper itself, by using an algorithms
 *  * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */
import android.util.Log;
import android.widget.HeaderViewListAdapter;

import java.util.Random;

public class Generator {

    /**
     * generates the minesweeper game by using a given wifth, height and number of boms.
     * THe random function is used to make each game completelty random
     * @param bombNum
     * @param width
     * @param height
     * @return
     */
    public  static int[][] generate(int bombNum, final int width, final int height){
        //used to randomly generate numbers
        Random r = new Random();
        int [][] grid = new int[width][height];
        for(int x = 0; x < width; x++){
            grid[x] = new int[height]; //creating the 2d array
        }

        //make bombs

        while(bombNum > 0){
            int x = r.nextInt(width);
            int y = r.nextInt(height);


            if (grid[x][y] != -1){ //if  there is not a bomb then add a bomb
                grid[x][y] = -1;
                bombNum--; //decrease bomb number
            }
        }
        grid = calculateNeighbours(grid,width,height);


        return grid;

    }

    /**
     * calculates the number of neighbours around a given cell
     * @param grid
     * @param width
     * @param height
     * @return
     */
    private static int[][] calculateNeighbours( int[][] grid, final int width, final int height){
        for (int x =0; x < width; x++){ //loop through the entire grid
            for (int y = 0; y < height ; y++){
            grid[x][y] = getNeighbourNumber(grid,x,y,width,height);

            }
        }
        return grid;
    }

    private static int getNeighbourNumber(final int grid[][], final int x, final int y, final int width, final int height){
        //check if the position we are standing on is a bomb
        if (grid[x][y] == -1){
            return -1; //if a bomb is there we dont need to calculate any neighbours
        }

        int count = 0;
        //check all around the bomb for example:
        /*
        000
        0*0
        000
        */
        //the algorithm will check each of the zeros if there is a bomb there or not.

        if( isMineAt(grid,x - 1 ,y + 1,width,height)) count++; // top-left
        if( isMineAt(grid,x     ,y + 1,width,height)) count++; // top
        if( isMineAt(grid,x + 1 ,y + 1,width,height)) count++; // top-right
        if( isMineAt(grid,x - 1 ,y    ,width,height)) count++; // left
        if( isMineAt(grid,x + 1 ,y    ,width,height)) count++; // right
        if( isMineAt(grid,x - 1 ,y - 1,width,height)) count++; // bottom-left
        if( isMineAt(grid,x     ,y - 1,width,height)) count++; // bottom
        if( isMineAt(grid,x + 1 ,y - 1,width,height)) count++; // bottom-right


       return  count;
    }

    /**
     * Check to see if there is a mine at a certain position in the grid.
     * @param grid
     * @param x
     * @param y
     * @param width
     * @param height
     * @return boolean
     */
    private static boolean isMineAt(final int [][] grid, final int x, final int y, final int width, final int height){
        //check if the mine is in the range of the array
        if (x >= 0 && y >= 0 && x < width &&  y < height){
            if (grid[x][y] == -1 ){ //if its a bomb
            return  true;
            }
        }
        return false; //its not a bomb
    }
}
