package com.example.minesweeper;
/**   This class is responsible for creating an object which is a player. It has the attributes name and score that can be accessed using getters and setters
 *  * @author Alex Palmer
 * @author jz015642@student.reading.ac.uk
 * @version 1.0
 */
public class Player {

    private String name;
    private int score;

    public Player() { }
    public  Player(String name, int score){
        this.name = name;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}